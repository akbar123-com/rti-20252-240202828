# Tinjauan Pustaka dan Landasan Teori

## 1. State of the Art (Penelitian Terdahulu)
Berbagai penelitian telah mengkaji pemanfaatan database untuk teknologi Internet of Things (IoT). Salsabila et al. (2022) membuktikan bahwa pengiriman data Beat Per Minute (BPM) menggunakan protokol IoT (seperti XMPP pada Raspberry Pi) dapat mencapai latensi jaringan yang sangat rendah. Di sisi lain, terkait dengan arsitektur penyimpanan di sisi server, Ahsa et al. (2023) dan Putra et al. (2022) telah melakukan pengujian performa kueri CRUD pada MySQL dan PostgreSQL. Kedua riset tersebut menyimpulkan bahwa PostgreSQL mencatatkan waktu respons kueri yang lebih unggul dibandingkan MySQL.

Namun, terdapat celah kosong (research gap) dari penelitian-penelitian terdahulu. Riset mengenai IoT (seperti yang dilakukan Lim et al., 2023) umumnya hanya berfokus pada perakitan sensor (MAX86150/MAX30102) dan transmisi nirkabelnya tanpa menguji kapasitas database server di ujung sistem. Sebaliknya, penelitian yang mengevaluasi MySQL dan PostgreSQL selama ini hanya menggunakan set dataset statis (seperti file CSV atau data akademik buatan) yang diimpor secara sekaligus ke dalam komputer lokal. Belum ada pengujian komparatif head-to-head antara MySQL dan PostgreSQL yang secara khusus dipaksa menahan hantaman aliran data beruntun tanpa jeda (continuous streaming) dari perangkat fisik sensor medis yang berfrekuensi tinggi. Penelitian ini hadir untuk menutup celah tersebut.

## 2. Landasan Teori
### 2.1 Aliran Data Sensor Medis (MAX30102)
Sensor MAX30102 adalah modul terintegrasi untuk pulse oximetry dan pemantau detak jantung yang menggunakan cahaya (LED merah dan inframerah) untuk mendeteksi volume aliran darah. Pada implementasi IoT medis, sensor ini digabungkan dengan mikrokontroler seperti ESP32 untuk memproduksi data secara terus-menerus (frekuensi tinggi). Karakteristik utama dari data ini adalah time-series continuous streaming, di mana paket data dikirimkan satu per satu dalam orde milidetik tanpa henti.

### 2.2 Sistem Manajemen Basis Data Relasional (RDBMS)
RDBMS adalah sistem yang menyimpan data dalam bentuk tabel terstruktur. 
* **MySQL:** Basis data open-source yang sangat populer karena ringan, didukung komunitas luas, dan memiliki performa baca/tulis yang sangat cepat untuk aplikasi standar. Sering dijadikan pilihan default (baseline) oleh pengembang IoT.
* **PostgreSQL:** Basis data open-source tingkat lanjut (*advanced*) yang secara ketat mematuhi standar SQL. PostgreSQL dirancang dengan arsitektur yang kuat untuk menangani kueri kompleks, beban data masif secara konkuren, dan memiliki stabilitas integritas data tingkat enterprise.

### 2.3 Insert Latency dan Bottleneck
*Insert Latency* (waktu simpan) adalah durasi waktu yang dibutuhkan oleh database engine sejak menerima perintah kueri penambahan data (`INSERT`) hingga data tersebut berhasil ditulis ke dalam disk. Ketika frekuensi kedatangan data dari sensor (misal: ratusan data per detik) melebihi batas kecepatan disk I/O atau kapasitas memori buffer dari database, maka akan terjadi antrean pemrosesan yang disebut bottlenec. Jika bottleneck ini terlalu parah, server akan menolak paket data baru, yang berujung pada hilangnya rekam medis (data loss).

## 3. Definisi Operasional Variabel
Penelitian ini menggunakan eksperimen komparatif dengan definisi operasional sebagai berikut:
1. **Variabel Independen (IV):** Jenis sistem database relasional yang diuji, yaitu MySQL (Kondisi A / Baseline) dan PostgreSQL (Kondisi B / Intervention).
2. **Variabel Dependen (DV):** * **Waktu Simpan (Insert Latency):** Durasi eksekusi kueri `INSERT` diukur dalam satuan milidetik (ms) menggunakan skrip pelacak waktu (microtime logging) di sisi backend.
   * **Beban Server:** Tingkat stres komputer *server* yang diukur melalui persentase (%) penggunaan RAM dan CPU menggunakan utilitas pemantauan sistem operasi.
3. **Variabel Kontrol (CV):** Lingkungan pengujian yang dijaga tetap konstan, meliputi spesifikasi hardware server, rute jaringan Wi-Fi lokal yang terisolasi, serta frekuensi tembakan data (jumlah *samples per second*) dari mikrokontroler ESP32 yang dikunci sama persis untuk kedua database.