# 03-teori

Dokumentasi landasan teori, definisi operasional, dan arsitektur sistem (Tahap 5) untuk penelitian performa database IoT.

## Isi yang diharapkan

* **Tinjauan Pustaka / State of the Art:** Menjelaskan posisi riset ini (pengujian continuous streaming medis) dibandingkan penelitian terdahulu yang ada di matriks literatur.
* **Landasan Teori:** Konsep dasar aliran data IoT medis, sensor MAX30102, arsitektur database relasional (MySQL & PostgreSQL), dan mekanisme *bottleneck*.
* **Definisi Operasional Variabel:** Penjelasan spesifik mengenai parameter ukur (waktu simpan dalam milidetik dan beban server dalam persentase) sesuai Worksheet 05.

## Berkas

* `tinjauan-pustaka.md` — draf Bab 2 (Related Work, Landasan Teori, & Definisi Operasional).